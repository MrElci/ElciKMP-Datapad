#yapılcaklar

#arasis ırkını yaz
#kayıp çağları yaz
#çağ sınıflandırmasını ages yazısına ekle
#olay şablonu yaz
#kaynak eksiğini tamamla
#anasayfayı hazırla
